Photoshop Scripting Sublime Text 2 Package
============================================

Sublime Text 2 package for Photoshop. 

## Build System

The build system will Run the script in Photoshop.

## Installation

- Download and unzip in your Sublime Text 2 packages folder.
- Rename the folder to `ExtendScript-PS`.

The "Packages" directory is located at:

- OS X

  <pre>~/Library/Application Support/Sublime Text 2/Packages</pre>

- Windows

  <pre>%APPDATA%/Sublime Text 2/Packages/</pre>


## Usage

Open Sublime Text 2 and go `Tools > Build System > ExtendScript-PS` and build with `⌘ + B` (OS X) `CTRL + B` (Windows)
Must "Run as Administrator" Sublime Text 2 on Windows!

## Credits
Original Package made by Sebastien Lavoie for AfterEffects (http://seblavoie.com/contact), adapted for Photoshop by Davide Barranca - www.davidebarranca.com

## Version History

### May 2013
V1.0 
- largely mutuated from Lavoie AE package

### April 2014
V2.0
- Removed JSX copying to PS Presets/Scripts/ folder
- set the default for PS CC