Photoshop Scripting Sublime Text 2 Package
============================================

Sublime Text 2 package for Photoshop. 

## Build System

The build system will : 

1. Copy your current .jsx file in your Photoshop Scripts folder so you don't have to develop in that folder.
2. Run the script in Photoshop.

## Installation

- Download and unzip in your Sublime Text 2 packages folder.
- Rename the folder to `ExtendScript-PS`.

The "Packages" directory is located at:

- OS X

  <pre>~/Library/Application Support/Sublime Text 2/Packages</pre>

- Windows

  <pre>%APPDATA%/Sublime Text 2/Packages/</pre>


## Usage

Open Sublime Text 2 and go `Tools > Build System > ExtendScript-PS` and build with `⌘ + B` (OS X) `CTRL + B` (Windows)
Must "Run as Administrator" Sublime Text 2 on Windows!

## Credits
Original Package made by Sebastien Lavoie for AfterEffects (http://seblavoie.com/contact), adapted for Photoshop by Davide Barranca - www.davidebarranca.com